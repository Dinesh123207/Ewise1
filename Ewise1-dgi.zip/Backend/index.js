const express = require("express");
const cors = require("cors");
const formidable = require("formidable"); // Replacing multer with formidable
const app = express();
const port = 5000;
const mongoDB = require("./db");
const seller = require("./models/SellersData");
mongoDB();

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "http://localhost:3000");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  next();
});

app.use(express.json());
app.use(cors());

app.use("/api", require("./Routes/BuyerUsers"));
app.use("/api", require("./Routes/SellerUsers"));
app.use("/api", require("./Routes/RegSellers"));
app.use("/api", require("./Routes/OrderData"));
app.use("/api", require("./Routes/Createitemsprice"));
app.use("/api", require("./Routes/RecyclePrice"));
app.use("/api", require("./Routes/DonatePrice"));

app.get("/", (req, res) => {
  res.send("Hello World! ---------------");
});
app.post("/api/createseller2", (req, res) => {
  const form = new formidable.IncomingForm();
  form.parse(req, async (err, fields, files) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: "Internal Server Error" });
    }

    // Extracting form fields
    const name = fields.name[0];
    const email = fields.email[0];
    const password = fields.password[0];
    const sellerType = fields.sellerType[0];
    const Address = fields.Address[0];
    const geolocation = fields.geolocation[0];
    const PhoneNum = fields.PhoneNum[0];
    const mapLink = fields.mapLink;
    const imglink = fields.imglink;
    const file = files.file; // Accessing the file

    console.log("Received Form Data:");
    console.log({
      name,
      email,
      password,
      sellerType,
      Address,
      geolocation,
      PhoneNum,
      mapLink,
      imglink,
    });

    try {
      // Storing the data into the database using seller.create
      await seller.create({
        name: name,
        email: email,
        password: password,
      });

      // Sending success response
      res.status(200).json({
        success: true,
        message: "Seller created successfully",
        data: {
          name,
          email,
          sellerType,
          Address,
          mapLink,
          imglink,
          PhoneNum,
          file,
        },
      });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal Server Error" });
    }
  });
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
