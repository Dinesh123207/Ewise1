const mongoose = require("mongoose");
const mongoURI =
  "mongodb+srv://Priyam:L6U6GkmY0TFX3wzc@cluster0.5d5ec0g.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
const mongoDB = async () => {
  try {
    mongoose.connect(mongoURI, { useNewUrlParser: true });
    console.log("Connected");
  } catch (error) {
    console.log(error);
  }
};

module.exports = mongoDB;
