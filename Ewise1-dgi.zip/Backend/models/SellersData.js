const mongoose = require("mongoose");
const { Schema } = mongoose;

const SellerSchema = new Schema({
  name: {
    type: String,
  },
  email: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  sellerType: {
    type: String,
  },
  Address: {
    type: String,
  },
  myDateField: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model("seller", SellerSchema);
